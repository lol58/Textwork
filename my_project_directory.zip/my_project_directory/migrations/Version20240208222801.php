<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240208222801 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE User (
            id INT AUTO_INCREMENT NOT NULL,
            text LONGTEXT NOT NULL,
            email VARCHAR(255) NOT NULL,
            color INT NOT NULL,
            geometrik INT NOT NULL,
            image INT NOT NULL,
            PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB ');
            
        $this->addSql('CREATE TABLE Admin (
            id INT AUTO_INCREMENT NOT NULL,
            login VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB ');

        $this->addSql('CREATE TABLE Color (
            id INT AUTO_INCREMENT NOT NULL,
            color VARCHAR(255) NOT NULL,
            PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB ');

        $this->addSql('CREATE TABLE Geometric (
            id INT AUTO_INCREMENT NOT NULL,
            figure VARCHAR(255) NOT NULL,
            PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB ');

        $this->addSql('CREATE TABLE Images (
            id INT AUTO_INCREMENT NOT NULL,
            URL LONGTEXT NOT NULL,
            PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB ');

    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE User');
        $this->addSql('DROP TABLE Admin');
        $this->addSql('DROP TABLE Color');
        $this->addSql('DROP TABLE Geometric');
        $this->addSql('DROP TABLE Images');

    }
}
